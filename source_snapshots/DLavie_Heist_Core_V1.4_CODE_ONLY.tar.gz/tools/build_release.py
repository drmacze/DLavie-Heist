from pathlib import Path
import zipfile, shutil
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'src'; OUT=ROOT/'releases'/'v1.4'
OUT.mkdir(parents=True,exist_ok=True)

def zip_dir(src,out):
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(src.rglob('*')):
            if p.is_file(): z.write(p,p.relative_to(src).as_posix())

bp=OUT/'DLavie_Heist_Core_V1.4[BP].mcpack'
rp=OUT/'DLavie_Heist_Core_V1.4[RP].mcpack'
zip_dir(SRC/'behavior_pack',bp); zip_dir(SRC/'resource_pack',rp)
outer=OUT/'DLavie_Heist_Core_V1.4.mcaddon'
with zipfile.ZipFile(outer,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.write(bp,bp.name); z.write(rp,rp.name)
print(outer)
