from pathlib import Path
import json, subprocess, zipfile, re, sys
ROOT=Path(__file__).resolve().parents[1]; SRC=ROOT/'src'; OUT=ROOT/'releases'/'v1.4'
errors=[]; checks=[]
def ok(name,cond=True):
    checks.append((name,bool(cond)))
    if not cond: errors.append(name)
# JSON
jsons=list(SRC.rglob('*.json'))
for p in jsons:
    try: json.load(open(p,encoding='utf-8'))
    except Exception as e: errors.append(f'JSON {p}: {e}')
ok(f'JSON strict parse ({len(jsons)} files)', not any(x.startswith('JSON ') for x in errors))
# JS
for p in (SRC/'behavior_pack'/'scripts').glob('*.js'):
    r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
    ok(f'JS syntax {p.name}',r.returncode==0)
# version/deps
bp=json.load(open(SRC/'behavior_pack'/'manifest.json')); rp=json.load(open(SRC/'resource_pack'/'manifest.json'))
ok('BP v1.4',bp['header']['version']==[1,4,0]); ok('RP v1.4',rp['header']['version']==[1,4,0])
ok('@minecraft/server 2.9.0',any(d.get('module_name')=='@minecraft/server' and d.get('version')=='2.9.0' for d in bp['dependencies']))
ok('@minecraft/server-ui 2.1.0',any(d.get('module_name')=='@minecraft/server-ui' and d.get('version')=='2.1.0' for d in bp['dependencies']))
# vault front and interaction
block=json.load(open(SRC/'behavior_pack'/'blocks'/'vault_safe.json'))['minecraft:block']
rot={}
for p in block['permutations']:
    t=p.get('components',{}).get('minecraft:transformation')
    if not t: continue
    m=re.search(r"== '([^']+)'",p.get('condition',''))
    if m: rot[m.group(1)]=t['rotation']
ok('vault front standardized rotations',rot.get('north')==[0,0,0] and rot.get('south')==[0,180,0] and rot.get('west')==[0,90,0] and rot.get('east')==[0,270,0])
main=(SRC/'behavior_pack'/'scripts'/'main.js').read_text()
ok('front-face interaction guard','FRONT DOOR ONLY' in main and 'interaction.face' in main and 'isFrontInteraction' in main)
ok('close cinematic four phases','const shotSets = [' in main and 'progress < 0.75 ? 2 : 3' in main and '1.55, 0.95' in main)
ok('animated final open','animation.dlv.heist.turn_handle' in main and 'animation.dlv.heist.pull_door' in main)
ok('animated cash collection','animation.dlv.heist.collect_cash' in main and 'animation.dlv.heist.stow_cash' in main)
ok('four interactive checks',main.count('setbackSeconds:')==4 and 'RELEASE BOLTS' in main)
# squad/grave
sq=(SRC/'behavior_pack'/'scripts'/'squad_loot.js').read_text()
ok('spectator mode', 'GameMode.Spectator' in sq and 'SQUAD WIPED' in sq and 'resetSquad' in sq)
ok('spawn-point reset','getSpawnPoint' in sq and 'teleportToRoundSpawn' in sq)
ok('grave on player death','spawnGrave(player' in sq and 'entityDie.subscribe' in sq)
ids=set(re.findall(r'"((?:gun|ammo|grenade|melee):[a-zA-Z0-9_]+)"',sq))
ok(f'AG2 whitelist embedded ({len(ids)} ids)',len(ids)==79)
ok('AG2-only loot namespaces',all(i.split(':',1)[0] in {'gun','ammo','grenade','melee'} for i in ids))
ok('grave interact loot UI','playerInteractWithEntity.subscribe' in sq and 'AG2 GRAVE CACHE' in sq)
for f in ['ag2_grave.png','ag2_grave_normal.png','ag2_grave_mer.png','ag2_grave.texture_set.json']:
    ok('grave PBR '+f,(SRC/'resource_pack'/'textures'/'entity'/f).exists())
ok('grave 3D geometry',(SRC/'resource_pack'/'models'/'entity'/'ag2_grave.geo.json').exists())
# animations
anim=json.load(open(SRC/'resource_pack'/'animations'/'heist_player.animation.json'))['animations']
needed={'animation.dlv.heist.inspect_lock','animation.dlv.heist.wedge_crowbar','animation.dlv.heist.pry_left','animation.dlv.heist.pry_right','animation.dlv.heist.shoulder_lever','animation.dlv.heist.turn_handle','animation.dlv.heist.pull_door','animation.dlv.heist.collect_cash','animation.dlv.heist.stow_cash'}
ok('expanded animation set',needed.issubset(anim))
# archive if built
outer=OUT/'DLavie_Heist_Core_V1.4.mcaddon'
if outer.exists():
    with zipfile.ZipFile(outer) as z: ok('MCADDON CRC',z.testzip() is None and len(z.namelist())==2)
for name,passed in checks: print(('PASS' if passed else 'FAIL'),name)
if errors:
    print('\nVALIDATION: FAIL'); [print('-',e) for e in errors]; sys.exit(1)
print('\nVALIDATION: PASS')
